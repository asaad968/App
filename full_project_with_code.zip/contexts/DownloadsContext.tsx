import createContextHook from '@nkzw/create-context-hook';
import { useState, useEffect, useCallback, useMemo } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
export type SocialPlatform = 'instagram' | 'tiktok' | 'twitter' | 'facebook' | 'youtube';
export type DownloadItem = {
id: string;
url: string;
platform: SocialPlatform;
platformName: string;
title: string;
date: string;
thumbnail?: string;
};
const STORAGE_KEY = '@video_downloader_history';
export const [DownloadsProvider, useDownloads] = createContextHook(() => {
const [downloads, setDownloads] = useState
([]);
const [isLoading, setIsLoading] = useState
(true);
useEffect(() => {
loadDownloads();
}, []);
const loadDownloads = async () => {
try {
const stored = await AsyncStorage.getItem(STORAGE_KEY);
if (stored) {
const parsed = JSON.parse(stored) as DownloadItem[];
setDownloads(parsed);
}
} catch (error) {
console.error('Error loading downloads:', error);
} finally {
setIsLoading(false);
}
};
const saveDownloads = async (newDownloads: DownloadItem[]) => {
try {
await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(newDownloads));
} catch (error) {
console.error('Error saving downloads:', error);
}
};
const addDownload = useCallback((download: Omit
) => {
const newDownload: DownloadItem = {
...download,
id: Date.now().toString(),
date: new Date().toISOString().split('T')[0],
};
setDownloads((prev) => {
const updated = [newDownload, ...prev];
saveDownloads(updated);
return updated;
});
}, []);
const removeDownload = useCallback((id: string) => {
setDownloads((prev) => {
const updated = prev.filter((item) => item.id !== id);
saveDownloads(updated);
return updated;
});
}, []);
const clearAllDownloads = useCallback(() => {
setDownloads([]);
saveDownloads([]);
}, []);
return useMemo(() => ({
downloads,
isLoading,
addDownload,
removeDownload,
clearAllDownloads,
}), [downloads, isLoading, addDownload, removeDownload, clearAllDownloads]);
});