import { LinearGradient } from 'expo-linear-gradient';
import { useState } from 'react';
import {
StyleSheet,
Text,
View,
TextInput,
TouchableOpacity,
ScrollView,
ActivityIndicator,
Alert,
Platform as RNPlatform,
} from 'react-native';
import { Download, Link as LinkIcon, Instagram, Youtube } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import Colors from '@/constants/colors';
import type { SocialPlatform } from '@/contexts/DownloadsContext';
type PlatformType = SocialPlatform | 'unknown';
const platformPatterns: Record
= {
instagram: [/instagram\.com/, /instagr\.am/],
tiktok: [/tiktok\.com/, /vm\.tiktok\.com/],
twitter: [/twitter\.com/, /x\.com/, /t\.co/],
facebook: [/facebook\.com/, /fb\.watch/, /fb\.com/],
youtube: [/youtube\.com/, /youtu\.be/],
unknown: [],
};
const platformNames: Record
= {
instagram: 'Instagram',
tiktok: 'TikTok',
twitter: 'Twitter/X',
facebook: 'Facebook',
youtube: 'YouTube',
unknown: 'Unknown',
};
export default function DownloaderScreen() {
const [url, setUrl] = useState
('');
const [loading, setLoading] = useState
(false);
const [detectedPlatform, setDetectedPlatform] = useState
('unknown');
const detectPlatform = (inputUrl: string): PlatformType => {
for (const [platform, patterns] of Object.entries(platformPatterns)) {
if (platform === 'unknown') continue;
for (const pattern of patterns) {
if (pattern.test(inputUrl)) {
return platform as PlatformType;
}
}
}
return 'unknown';
};
const handleUrlChange = (text: string) => {
setUrl(text);
if (text.length > 10) {
const platform = detectPlatform(text);
setDetectedPlatform(platform);
} else {
setDetectedPlatform('unknown');
}
};
const handleDownload = async () => {
if (!url.trim()) {
Alert.alert('خطأ', 'الرجاء إدخال رابط الفيديو');
return;
}
const platform = detectPlatform(url);
if (platform === 'unknown') {
Alert.alert('خطأ', 'الرابط غير مدعوم. الرجاء إدخال رابط من منصة مدعومة');
return;
}
if (RNPlatform.OS !== 'web') {
Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
}
setLoading(true);
setTimeout(() => {
setLoading(false);
Alert.alert(
'نجح التحميل',
`تم اكتشاف الفيديو من ${platformNames[platform]}!\n\nملاحظة: هذا تطبيق تجريبي. للتحميل الفعلي، يجب ربط API خاص بتحميل الفيديوهات.`,
[{ text: 'حسناً' }]
);
setUrl('');
setDetectedPlatform('unknown');
}, 2000);
};
const renderPlatformBadge = () => {
if (detectedPlatform === 'unknown') return null;
const platformColor = Colors.platforms[detectedPlatform as SocialPlatform];
return (
{platformNames[detectedPlatform]}
);
};
const PlatformCard = ({ platform, icon: Icon }: { platform: SocialPlatform; icon: any }) => (
{platformNames[platform]}
);
return (
colors={[Colors.primary, Colors.secondary]}
start={{ x: 0, y: 0 }}
end={{ x: 1, y: 1 }}
style={styles.header}
>
تحميل الفيديوهات
من جميع منصات التواصل الاجتماعي
الصق رابط الفيديو
style={styles.input}
placeholder="https://..."
placeholderTextColor={Colors.mediumGray}
value={url}
onChangeText={handleUrlChange}
autoCapitalize="none"
autoCorrect={false}
keyboardType="url"
returnKeyType="done"
editable={!loading}
/>
{renderPlatformBadge()}
style={[styles.downloadButton, loading && styles.downloadButtonDisabled]}
onPress={handleDownload}
disabled={loading}
activeOpacity={0.8}
>
colors={loading ? [Colors.mediumGray, Colors.mediumGray] : [Colors.primary, Colors.secondary]}
start={{ x: 0, y: 0 }}
end={{ x: 1, y: 0 }}
style={styles.downloadButtonGradient}
>
{loading ? (
) : (
)}
{loading ? 'جاري التحميل...' : 'تحميل الفيديو'}
المنصات المدعومة
كيفية الاستخدام
1
انسخ رابط الفيديو من التطبيق
2
الصق الرابط في الحقل أعلاه
3
اضغط على زر التحميل
);
}
const styles = StyleSheet.create({
container: {
flex: 1,
backgroundColor: Colors.lightGray,
},
header: {
paddingTop: 20,
paddingBottom: 30,
paddingHorizontal: 20,
alignItems: 'center',
borderBottomLeftRadius: 30,
borderBottomRightRadius: 30,
},
headerTitle: {
fontSize: 28,
fontWeight: '700' as const,
color: '#fff',
marginTop: 12,
textAlign: 'center',
},
headerSubtitle: {
fontSize: 16,
color: '#fff',
opacity: 0.9,
marginTop: 6,
textAlign: 'center',
},
content: {
flex: 1,
paddingHorizontal: 20,
},
inputSection: {
marginTop: 24,
backgroundColor: '#fff',
borderRadius: 20,
padding: 20,
shadowColor: '#000',
shadowOffset: { width: 0, height: 2 },
shadowOpacity: 0.1,
shadowRadius: 8,
elevation: 3,
},
sectionTitle: {
fontSize: 18,
fontWeight: '600' as const,
color: Colors.dark,
marginBottom: 16,
textAlign: 'right',
},
inputContainer: {
flexDirection: 'row',
alignItems: 'center',
backgroundColor: Colors.lightGray,
borderRadius: 12,
paddingHorizontal: 16,
height: 56,
},
inputIcon: {
marginRight: 12,
},
input: {
flex: 1,
fontSize: 16,
color: Colors.dark,
textAlign: 'left',
},
platformBadge: {
flexDirection: 'row',
alignItems: 'center',
alignSelf: 'flex-start',
paddingHorizontal: 12,
paddingVertical: 8,
borderRadius: 20,
marginTop: 12,
},
platformDot: {
width: 8,
height: 8,
borderRadius: 4,
marginRight: 8,
},
platformText: {
fontSize: 14,
fontWeight: '600' as const,
},
downloadButton: {
marginTop: 20,
borderRadius: 12,
overflow: 'hidden',
},
downloadButtonDisabled: {
opacity: 0.7,
},
downloadButtonGradient: {
flexDirection: 'row',
alignItems: 'center',
justifyContent: 'center',
paddingVertical: 16,
gap: 10,
},
downloadButtonText: {
fontSize: 18,
fontWeight: '600' as const,
color: '#fff',
},
platformsSection: {
marginTop: 24,
backgroundColor: '#fff',
borderRadius: 20,
padding: 20,
shadowColor: '#000',
shadowOffset: { width: 0, height: 2 },
shadowOpacity: 0.1,
shadowRadius: 8,
elevation: 3,
},
platformsGrid: {
flexDirection: 'row',
flexWrap: 'wrap',
gap: 12,
},
platformCard: {
width: '30%',
aspectRatio: 1,
backgroundColor: Colors.lightGray,
borderRadius: 16,
alignItems: 'center',
justifyContent: 'center',
padding: 12,
},
platformIconContainer: {
width: 48,
height: 48,
borderRadius: 24,
alignItems: 'center',
justifyContent: 'center',
marginBottom: 8,
},
platformCardText: {
fontSize: 12,
fontWeight: '600' as const,
color: Colors.dark,
textAlign: 'center',
},
infoSection: {
marginTop: 24,
marginBottom: 32,
backgroundColor: '#fff',
borderRadius: 20,
padding: 20,
shadowColor: '#000',
shadowOffset: { width: 0, height: 2 },
shadowOpacity: 0.1,
shadowRadius: 8,
elevation: 3,
},
infoTitle: {
fontSize: 18,
fontWeight: '600' as const,
color: Colors.dark,
marginBottom: 16,
textAlign: 'right',
},
infoSteps: {
gap: 16,
},
infoStep: {
flexDirection: 'row',
alignItems: 'center',
gap: 12,
},
stepNumber: {
width: 32,
height: 32,
borderRadius: 16,
backgroundColor: `${Colors.primary}20`,
alignItems: 'center',
justifyContent: 'center',
},
stepNumberText: {
fontSize: 16,
fontWeight: '700' as const,
color: Colors.primary,
},
stepText: {
flex: 1,
fontSize: 15,
color: Colors.dark,
textAlign: 'right',
},
});