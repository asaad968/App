import { LinearGradient } from 'expo-linear-gradient';
import { StyleSheet, Text, View, ScrollView, TouchableOpacity } from 'react-native';
import { Clock, Download, Trash2, ExternalLink } from 'lucide-react-native';
import Colors from '@/constants/colors';
type DownloadItem = {
id: string;
url: string;
platform: string;
title: string;
date: string;
thumbnail?: string;
};
const mockDownloads: DownloadItem[] = [
{
id: '1',
url: 'https://instagram.com/p/example1',
platform: 'Instagram',
title: 'فيديو رائع من Instagram',
date: '2025-09-30',
},
{
id: '2',
url: 'https://youtube.com/watch?v=example2',
platform: 'YouTube',
title: 'فيديو تعليمي مفيد',
date: '2025-09-29',
},
{
id: '3',
url: 'https://tiktok.com/@user/video/example3',
platform: 'TikTok',
title: 'فيديو ترفيهي قصير',
date: '2025-09-28',
},
];
export default function HistoryScreen() {
const getPlatformColor = (platform: string): string => {
const platformLower = platform.toLowerCase();
if (platformLower.includes('instagram')) return Colors.platforms.instagram;
if (platformLower.includes('youtube')) return Colors.platforms.youtube;
if (platformLower.includes('tiktok')) return Colors.platforms.tiktok;
if (platformLower.includes('twitter') || platformLower.includes('x')) return Colors.platforms.twitter;
if (platformLower.includes('facebook')) return Colors.platforms.facebook;
return Colors.mediumGray;
};
const DownloadCard = ({ item }: { item: DownloadItem }) => {
const platformColor = getPlatformColor(item.platform);
return (
{item.platform}
{item.date}
{item.title}
{item.url}
فتح
إعادة تحميل
);
};
return (
colors={[Colors.primary, Colors.secondary]}
start={{ x: 0, y: 0 }}
end={{ x: 1, y: 1 }}
style={styles.header}
>
سجل التحميلات
جميع الفيديوهات التي قمت بتحميلها
{mockDownloads.length === 0 ? (
لا توجد تحميلات بعد
ابدأ بتحميل أول فيديو لك!
) : (
{mockDownloads.map((item) => (
))}
)}
);
}
const styles = StyleSheet.create({
container: {
flex: 1,
backgroundColor: Colors.lightGray,
},
header: {
paddingTop: 20,
paddingBottom: 30,
paddingHorizontal: 20,
alignItems: 'center',
borderBottomLeftRadius: 30,
borderBottomRightRadius: 30,
},
headerTitle: {
fontSize: 28,
fontWeight: '700' as const,
color: '#fff',
marginTop: 12,
textAlign: 'center',
},
headerSubtitle: {
fontSize: 16,
color: '#fff',
opacity: 0.9,
marginTop: 6,
textAlign: 'center',
},
content: {
flex: 1,
paddingHorizontal: 20,
},
emptyState: {
alignItems: 'center',
justifyContent: 'center',
paddingVertical: 80,
},
emptyTitle: {
fontSize: 20,
fontWeight: '600' as const,
color: Colors.dark,
marginTop: 16,
textAlign: 'center',
},
emptySubtitle: {
fontSize: 16,
color: Colors.mediumGray,
marginTop: 8,
textAlign: 'center',
},
downloadsList: {
paddingTop: 24,
paddingBottom: 32,
gap: 16,
},
downloadCard: {
backgroundColor: '#fff',
borderRadius: 16,
padding: 16,
shadowColor: '#000',
shadowOffset: { width: 0, height: 2 },
shadowOpacity: 0.1,
shadowRadius: 8,
elevation: 3,
},
cardHeader: {
flexDirection: 'row',
justifyContent: 'space-between',
alignItems: 'center',
marginBottom: 12,
},
platformBadge: {
flexDirection: 'row',
alignItems: 'center',
paddingHorizontal: 10,
paddingVertical: 6,
borderRadius: 12,
},
platformDot: {
width: 6,
height: 6,
borderRadius: 3,
marginRight: 6,
},
platformText: {
fontSize: 12,
fontWeight: '600' as const,
},
dateText: {
fontSize: 12,
color: Colors.mediumGray,
},
titleText: {
fontSize: 16,
fontWeight: '600' as const,
color: Colors.dark,
marginBottom: 8,
textAlign: 'right',
},
urlText: {
fontSize: 13,
color: Colors.mediumGray,
marginBottom: 16,
textAlign: 'left',
},
cardActions: {
flexDirection: 'row',
gap: 12,
borderTopWidth: 1,
borderTopColor: Colors.lightGray,
paddingTop: 12,
},
actionButton: {
flexDirection: 'row',
alignItems: 'center',
gap: 6,
paddingVertical: 8,
paddingHorizontal: 12,
backgroundColor: Colors.lightGray,
borderRadius: 8,
},
actionButtonText: {
fontSize: 13,
fontWeight: '600' as const,
color: Colors.primary,
},
});