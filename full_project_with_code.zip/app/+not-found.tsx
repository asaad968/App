import { Link, Stack } from 'expo-router';
import { StyleSheet, View, Text } from 'react-native';
import { AlertCircle } from 'lucide-react-native';
import Colors from '@/constants/colors';
export default function NotFoundScreen() {
return (
<>
الصفحة غير موجودة
عذراً، الصفحة التي تبحث عنها غير موجودة
العودة للرئيسية
);
}
const styles = StyleSheet.create({
container: {
flex: 1,
alignItems: 'center',
justifyContent: 'center',
padding: 20,
backgroundColor: Colors.lightGray,
},
title: {
fontSize: 24,
fontWeight: '700' as const,
color: Colors.dark,
marginTop: 20,
textAlign: 'center',
},
subtitle: {
fontSize: 16,
color: Colors.mediumGray,
marginTop: 12,
textAlign: 'center',
},
link: {
marginTop: 32,
paddingVertical: 12,
paddingHorizontal: 24,
backgroundColor: Colors.primary,
borderRadius: 12,
},
linkText: {
fontSize: 16,
fontWeight: '600' as const,
color: '#fff',
},
});
assets
images
adaptive-icon.png
favicon.png
icon.png
splash-icon.png
constants