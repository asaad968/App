const tintColorLight = "#8B5CF6";
export default {
light: {
text: "#000",
background: "#fff",
tint: tintColorLight,
tabIconDefault: "#ccc",
tabIconSelected: tintColorLight,
},
primary: "#8B5CF6",
secondary: "#EC4899",
accent: "#06B6D4",
success: "#10B981",
warning: "#F59E0B",
error: "#EF4444",
dark: "#1F2937",
darkCard: "#374151",
lightGray: "#F3F4F6",
mediumGray: "#9CA3AF",
platforms: {
instagram: "#E4405F",
tiktok: "#000000",
twitter: "#1DA1F2",
facebook: "#1877F2",
youtube: "#FF0000",
}
};
contexts